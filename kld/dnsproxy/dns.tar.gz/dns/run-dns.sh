#!/bin/bash

/sbin/start-stop-daemon -S -c nobody -b -o -q -m \
-N -10 \
-p /var/run/run-dp.pid \
-x /usr/local/bin/dp -- \
-l 0.0.0.0 -p 5333 \
-u /etc/dp/cn-lite-tls-domain.txt \
-u /etc/dp/chnlist.txt \
-u /etc/dp/gfwlist-google.txt \
-u /etc/dp/gfwlist-cloudflare2.txt \
-u /etc/dp/gfwlist-cloudflare1.txt \
-u /etc/dp/gfwlist-opendns.txt \
-u /etc/dp/gfwlist-cloudflare3.txt \
-u /etc/dp/gfwlist-adguard.txt \
-u /etc/dp/gfwlist-quad.txt \
-f 9.9.9.11:9953 \
-f 208.67.220.220:443 \
-f 94.140.14.140:5353 \
-b 223.6.6.6 \
-b 119.29.29.29 \
-b 114.114.114.114 \
-b 1.2.4.8 \
--all-servers \
--edns \
--cache \
--cache-optimistic \
--cache-min-ttl=3600 \
--fastest-addr
